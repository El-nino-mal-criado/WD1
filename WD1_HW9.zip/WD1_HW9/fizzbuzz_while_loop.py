import sys

min_num = 1
max_num = 100
fizz = "fizz"
buzz = "buzz"
number = input(f"Enter an integer number between {min_num} and {max_num}: ")

try:
    number = int(number)
    if number < min_num:
        print(f"ERROR: The number you have entered is lower than the lower limit ({number} < {min_num})! "
              f"Please try again by rerunning the program.")
        sys.exit()
    elif number > max_num:
        print(f"ERROR: The number you have entered is higher than the upper limit ({number} > {max_num})! "
              f"Please try again by rerunning the program.")
        sys.exit()
except ValueError:
    print("ERROR: The number you have entered is not an integer! Please try again by rerunning the program.")
    sys.exit()

i = 1 #index in while loop

while i <= number:
    if i % 3 == 0 and i % 5 == 0:
        print(fizz+buzz)
    elif i % 3 == 0:
        print(fizz)
    elif i % 5 == 0:
        print(buzz)
    else:
        print(i)

    i += 1
