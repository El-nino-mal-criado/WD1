print("Welcome to the kilometers to miles converter!")

another_calculus = "yes"

while another_calculus == "yes":
    kms = input("Please, enter the value in kilometers: ").strip("km, kilometers, kilometer")
    try:
        kms = kms.replace(",", ".") # needed in case the user enter the number with a decimal comma instead of point
        kms = float(kms)
        miles = kms / 1.609344
        nautical_miles = kms / 1.852
        print(f"{kms} kilometers equals {miles} miles and {nautical_miles} nautical miles.")
        another_calculus = input("Would you like to perform another calculus (yes/no)? ").strip().lower()
        if another_calculus == "y":
            another_calculus = "yes"

    except ValueError:
        print("ERROR: The entered value is not a number. Please, retry!")

print("Thank you for using our kilometers to miles converter! Good bye.")