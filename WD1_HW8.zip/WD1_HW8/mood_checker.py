#mood checker programme
mood = input("Hello! In what mood are you today? [Write it in without block capital letters, please \U0001f642]: ")

if(mood == "happy"):
    print("It is great to see you happy! \U0001f600")
elif(mood == "nervous"):
    print("Take a deep breath three times!")
elif(mood == "sad"):
    print("So sorry to hear that \U0001f641 Go for a beer...life seems brighter after a few of them \U0001f601")
elif(mood == "excited"):
    print("Great to hear it \U0001f60d Keep on the good spirits!")
elif(mood == "relaxed"):
    print("That's the spirit \U0001f60e")
else:
    print("Error!!! Unknown mood \U0001f610")
