import random
print("Welcome to the game 'Guess the secret number'!")
min_number = 0
max_number = 9
num_trials = 5

secret_number = random.randint(min_number, max_number)
print("The computer has just generated the secret number. Guess which one it is! You have " + str(num_trials) + " trials.")
print("Hint: the number is an integer number between " + str(min_number) + " and " + str(max_number))


def play_a_round(n):
    guess = input("Trial " + str(n + 1) + ": Write your guess: ")
    success = False

    try:
        guess = int(guess)
    except ValueError: #necessary in case user enters a non int number
        if n == num_trials - 1:
            print("Wrong \U0001f641")
        else:
            print("Wrong \U0001f641 Read the hint and try again!")
        return success

    if guess == secret_number :
        print("That is correct! Bravo! \U0001f600")
        success = True
    elif guess != secret_number and n < num_trials - 1:
        print("Wrong \U0001f641 Try again!")
        success = False
    else:
        print("Wrong \U0001f641")
        success = False

    return success


successful_guess = False
for trial in range(num_trials):
    successful_guess = play_a_round(trial)
    if successful_guess:
        break

if not successful_guess:
    print("Game over! The secret number was: " + str(secret_number))

